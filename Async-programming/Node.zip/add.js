var a,b,c;
a= 1000;
b=2000;
c = a + b;

console.log(" Addition: "+c);
