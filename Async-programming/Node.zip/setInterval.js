//setInterval Function
console.log(" Before function executed.");

function demo(){
	console.log(" Demo function executed.");
}

setInterval(demo,2000);

console.log("After function executed.");