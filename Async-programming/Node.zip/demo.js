var a = [1, 2, 3, 4, 4, 50];
var b = [...a];
console.log(b);
